# P0-B native semantic control evidence r4

These are actual ChemDraw outputs for the 20 publicly preregistered synthetic
controls, not a private candidate or visual acceptance. Native source files and
sidecars are unchanged bytes. The final raw events journal contains machine-local
paths and is retained in the owner's private bundle, not in this public archive.

Source implementation 2d6ac0d8a510d912f8e03157cf182cd6ce403683; source freeze
e12acc3f84333125476d47a1c2187873d03378da56ed3c0117324dbc1006ee1f.
The source-tree includes all 33 frozen files and 24 input/manifest files. The
installed vendor binaries and dependencies are not redistributed. Exact runtime
and dependency identities are in the freeze; use the repository for the full
guarded regression suite. No reserved payload is included.

Reproduce the offline control comparison, without any native action, from the
extracted source-tree: python probes/verify_native_semantic_controls.py --native
../native-r4 --source-freeze ../source-freeze-r4.json --out ../new-analysis.
This command preserves all source/build/observer/graph/label/selection checks.

Computed native-control status is qualified_covered_branches (19 measured
branches, not every branch of the proposed profile). The history folder retains
each earlier source tree, synthetic native artifacts and comparison output.
Events and execution receipts there are explicitly sanitized derivatives with
original and derived hashes; the owner bundle retains original bytes. Independent
controller review and production admission remain separate; no private request
was replayed or run by the implementation task. Old 0.4 sidecars are refused by
the new reader. Overall product, native visual and human acceptance are not
established; Gold remains zero.
